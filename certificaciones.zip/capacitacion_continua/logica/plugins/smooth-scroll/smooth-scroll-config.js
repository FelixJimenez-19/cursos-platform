//var scroll = new SmoothScroll('a[href*="#"]');
//var scroll = new SmoothScroll('a[href*="#"]', {
//	speed: 300
//});
//var scroll = new SmoothScroll('a[href*="#"]', {
//	speed: 500,
//	speedAsDuration: true
//});