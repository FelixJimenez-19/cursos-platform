<?php
class EstrategiaDAO{
  private $conn;
  public function EstrategiaDAO(){
    $this->conn = new Mysql();
  }
  public function guardar($descripcion,$id_modelo_curso){
    $this->conn->query("INSERT INTO estrategia SET descripcion='$descripcion', id_modelo_curso=$id_modelo_curso");
  }
  public function findByIdModeloCurso($id){
    return $this->conn->query("SELECT * FROM estrategia WHERE id_modelo_curso=$id;");
  }
}
?>