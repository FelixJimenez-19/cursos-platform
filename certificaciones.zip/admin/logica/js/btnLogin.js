document.getElementById('btnAdministrador').addEventListener('click',function(e){
  document.querySelector(".logins").style.marginLeft = "-100%";
},false);
document.getElementById('btnProfesor').addEventListener('click',function(e){
  document.querySelector(".logins").style.marginLeft = "0%";
},false);