<?php
header("location: capacitacion_continua/presentacion/index.php");
?>