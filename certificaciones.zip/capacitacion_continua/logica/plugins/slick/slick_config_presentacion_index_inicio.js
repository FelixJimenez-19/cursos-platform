escalar_slick1();
function escalar_slick1(){
  if(window.innerWidth<=400){
    $('.items-slick1').slick({
      infinite: true,
      slidesToShow: 1,
      slidesToScroll: 1,
      nextArrow: $('.next1'),
      prevArrow: $('.previus1')
    });
  }else if(window.innerWidth<=700){
    $('.items-slick1').slick({
      infinite: true,
      slidesToShow: 2,
      slidesToScroll: 2,
      nextArrow: $('.next1'),
      prevArrow: $('.previus1')
    });
  }else if(window.innerWidth<=1050){
    $('.items-slick1').slick({
      infinite: true,
      slidesToShow: 3,
      slidesToScroll: 3,
      nextArrow: $('.next1'),
      prevArrow: $('.previus1')
    });
  }else if(window.innerWidth<=1400){
    $('.items-slick1').slick({
      infinite: true,
      slidesToShow: 4,
      slidesToScroll: 4,
      nextArrow: $('.next1'),
      prevArrow: $('.previus1')
    });
  }else if(window.innerWidth<=1750){
    $('.items-slick1').slick({
      infinite: true,
      slidesToShow: 5,
      slidesToScroll: 5,
      nextArrow: $('.next1'),
      prevArrow: $('.previus1')
    });
  }else if(window.innerWidth<=2100){
    $('.items-slick1').slick({
      infinite: true,
      slidesToShow: 6,
      slidesToScroll: 6,
      nextArrow: $('.next1'),
      prevArrow: $('.previus1')
    });
  }else if(window.innerWidth<=2450){
    $('.items-slick1').slick({
      infinite: true,
      slidesToShow: 7,
      slidesToScroll: 7,
      nextArrow: $('.next1'),
      prevArrow: $('.previus1')
    });
  }
}






escalar_slick2();
function escalar_slick2(){
  if(window.innerWidth<=400){
    $('.items-slick2').slick({
      infinite: true,
      slidesToShow: 1,
      slidesToScroll: 1,
      nextArrow: $('.next2'),
      prevArrow: $('.previus2')
    });
  }else if(window.innerWidth<=700){
    $('.items-slick2').slick({
      infinite: true,
      slidesToShow: 2,
      slidesToScroll: 2,
      nextArrow: $('.next2'),
      prevArrow: $('.previus2')
    });
  }else if(window.innerWidth<=1050){
    $('.items-slick2').slick({
      infinite: true,
      slidesToShow: 3,
      slidesToScroll: 3,
      nextArrow: $('.next2'),
      prevArrow: $('.previus2')
    });
  }else if(window.innerWidth<=1400){
    $('.items-slick2').slick({
      infinite: true,
      slidesToShow: 4,
      slidesToScroll: 4,
      nextArrow: $('.next2'),
      prevArrow: $('.previus2')
    });
  }else if(window.innerWidth<=1750){
    $('.items-slick2').slick({
      infinite: true,
      slidesToShow: 5,
      slidesToScroll: 5,
      nextArrow: $('.next2'),
      prevArrow: $('.previus2')
    });
  }else if(window.innerWidth<=2100){
    $('.items-slick2').slick({
      infinite: true,
      slidesToShow: 6,
      slidesToScroll: 6,
      nextArrow: $('.next2'),
      prevArrow: $('.previus2')
    });
  }else if(window.innerWidth<=2450){
    $('.items-slick2').slick({
      infinite: true,
      slidesToShow: 7,
      slidesToScroll: 7,
      nextArrow: $('.next2'),
      prevArrow: $('.previus2')
    });
  }
}






escalar_slick3();
function escalar_slick3(){
  if(window.innerWidth<=400){
    $('.items-slick3').slick({
      infinite: true,
      slidesToShow: 1,
      slidesToScroll: 1,
      nextArrow: $('.next3'),
      prevArrow: $('.previus3')
    });
  }else if(window.innerWidth<=700){
    $('.items-slick3').slick({
      infinite: true,
      slidesToShow: 2,
      slidesToScroll: 2,
      nextArrow: $('.next3'),
      prevArrow: $('.previus3')
    });
  }else if(window.innerWidth<=1050){
    $('.items-slick3').slick({
      infinite: true,
      slidesToShow: 3,
      slidesToScroll: 3,
      nextArrow: $('.next3'),
      prevArrow: $('.previus3')
    });
  }else if(window.innerWidth<=1400){
    $('.items-slick3').slick({
      infinite: true,
      slidesToShow: 4,
      slidesToScroll: 4,
      nextArrow: $('.next3'),
      prevArrow: $('.previus3')
    });
  }else if(window.innerWidth<=1750){
    $('.items-slick3').slick({
      infinite: true,
      slidesToShow: 5,
      slidesToScroll: 5,
      nextArrow: $('.next3'),
      prevArrow: $('.previus3')
    });
  }else if(window.innerWidth<=2100){
    $('.items-slick3').slick({
      infinite: true,
      slidesToShow: 6,
      slidesToScroll: 6,
      nextArrow: $('.next3'),
      prevArrow: $('.previus3')
    });
  }else if(window.innerWidth<=2450){
    $('.items-slick3').slick({
      infinite: true,
      slidesToShow: 7,
      slidesToScroll: 7,
      nextArrow: $('.next3'),
      prevArrow: $('.previus3')
    });
  }
}







escalar_slick4();
function escalar_slick4(){
  if(window.innerWidth<=400){
    $('.items-slick4').slick({
      infinite: true,
      slidesToShow: 1,
      slidesToScroll: 1,
      nextArrow: $('.next4'),
      prevArrow: $('.previus4')
    });
  }else if(window.innerWidth<=700){
    $('.items-slick4').slick({
      infinite: true,
      slidesToShow: 2,
      slidesToScroll: 2,
      nextArrow: $('.next4'),
      prevArrow: $('.previus4')
    });
  }else if(window.innerWidth<=1050){
    $('.items-slick4').slick({
      infinite: true,
      slidesToShow: 3,
      slidesToScroll: 3,
      nextArrow: $('.next4'),
      prevArrow: $('.previus4')
    });
  }else if(window.innerWidth<=1400){
    $('.items-slick4').slick({
      infinite: true,
      slidesToShow: 4,
      slidesToScroll: 4,
      nextArrow: $('.next4'),
      prevArrow: $('.previus4')
    });
  }else if(window.innerWidth<=1750){
    $('.items-slick4').slick({
      infinite: true,
      slidesToShow: 5,
      slidesToScroll: 5,
      nextArrow: $('.next4'),
      prevArrow: $('.previus4')
    });
  }else if(window.innerWidth<=2100){
    $('.items-slick4').slick({
      infinite: true,
      slidesToShow: 6,
      slidesToScroll: 6,
      nextArrow: $('.next4'),
      prevArrow: $('.previus4')
    });
  }else if(window.innerWidth<=2450){
    $('.items-slick4').slick({
      infinite: true,
      slidesToShow: 7,
      slidesToScroll: 7,
      nextArrow: $('.next4'),
      prevArrow: $('.previus4')
    });
  }
}